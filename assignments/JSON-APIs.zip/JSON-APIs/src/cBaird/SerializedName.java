package cBaird;

public @interface SerializedName {
}
